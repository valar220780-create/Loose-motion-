# Loose Motion (Stage 1)

## Build the APK
- **GitHub (phone friendly):** create a repo, upload all files, open Actions > Build APK > Run workflow. Download `LooseMotion-apk` from the run, unzip, install `app-debug.apk`.
- **Android Studio:** open the folder, Build > Build APK(s).

## Status
| Feature | Status |
|---|---|
| Dark UI shell, preview, multilayer timeline | Implemented |
| Add video/image/audio/text, drag clips, split, delete | Implemented |
| Undo/redo, frame step, play/pause, zoom, scrub | Implemented |
| Projects: save, autosave, recover, rename, duplicate, import/export file | Implemented |
| Effects (NODE VIDEO EFFECTS) | Planned: Stage 3 |
| Keyframes / graph editor | Planned: Stage 4 |
| TIME REMAPPING | Planned: Stage 5 |
| Export (720p-4K, fps, bitrate, codec) | Planned: Stage 6 |
| Chroma key, masks, tracking, nested comps | Planned: Stage 8 |

Known Stage 1 limits: preview plays one video and one audio clip at a time; multi-video compositing arrives with the GL compositor.
