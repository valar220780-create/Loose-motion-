package com.loosemotion.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel

val Bg = Color(0xFF0D0D12)
val Panel = Color(0xFF1A1A24)
val Panel2 = Color(0xFF252533)
val Purple = Color(0xFF8B5CF6)
val Blue = Color(0xFF3B82F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple, secondary = Blue, background = Bg,
                    surface = Panel, onSurface = Color.White, onBackground = Color.White,
                )
            ) {
                val vm: EditorViewModel = viewModel()
                EditorScreen(vm)
            }
        }
    }
}
