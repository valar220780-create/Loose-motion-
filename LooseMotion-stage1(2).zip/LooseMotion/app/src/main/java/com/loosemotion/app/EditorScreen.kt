package com.loosemotion.app

import android.net.Uri
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Canvas
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlin.math.abs

enum class Dlg { NONE, TEXT, SETTINGS, PROJECTS, EFFECTS, REMAP, EXPORT }

fun fmtTime(ms: Long, fps: Int): String {
    val s = ms / 1000
    val f = (ms % 1000) * fps / 1000
    return "%02d:%02d:%02d".format(s / 60, s % 60, f)
}

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf(Dlg.NONE) }

    val videoPlayer = remember { ExoPlayer.Builder(ctx).build() }
    val audioPlayer = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { videoPlayer.release(); audioPlayer.release() } }

    val pickVisual = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addMedia(it) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addMedia(it) }
    val exportFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { it?.let(vm::exportProjectFile) }
    val importFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importProjectFile) }

    // playback clock
    LaunchedEffect(vm.isPlaying) {
        if (vm.isPlaying) {
            var last = SystemClock.uptimeMillis()
            while (vm.isPlaying) {
                delay(16)
                val now = SystemClock.uptimeMillis()
                vm.playheadMs += now - last; last = now
                if (vm.playheadMs >= vm.totalMs) { vm.playheadMs = vm.totalMs; vm.isPlaying = false }
            }
        }
    }

    val activeVideo = vm.activeLayers(LayerType.VIDEO).lastOrNull()
    val activeAudio = vm.activeLayers(LayerType.AUDIO).lastOrNull()
    SyncPlayer(videoPlayer, activeVideo, vm.playheadMs, vm.isPlaying)
    SyncPlayer(audioPlayer, activeAudio, vm.playheadMs, vm.isPlaying)

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        TopBar(vm, onProjects = { dlg = Dlg.PROJECTS }, onSettings = { dlg = Dlg.SETTINGS }, onExport = { dlg = Dlg.EXPORT })
        PreviewPane(vm, videoPlayer, activeVideo != null, Modifier.weight(1f).fillMaxWidth())
        Transport(vm)
        TimelinePanel(vm, Modifier.fillMaxWidth().height(210.dp))
        ToolTray(
            vm,
            onMedia = { pickVisual.launch(arrayOf("video/*", "image/*")) },
            onAudio = { pickAudio.launch(arrayOf("audio/*")) },
            onText = { dlg = Dlg.TEXT },
            onEffects = { dlg = Dlg.EFFECTS },
            onRemap = { dlg = Dlg.REMAP },
        )
    }

    when (dlg) {
        Dlg.NONE -> {}
        Dlg.TEXT -> TextDialog({ dlg = Dlg.NONE }) { vm.addText(it); dlg = Dlg.NONE }
        Dlg.SETTINGS -> SettingsDialog(vm) { dlg = Dlg.NONE }
        Dlg.PROJECTS -> ProjectsDialog(vm, { dlg = Dlg.NONE },
            onExportFile = { exportFile.launch(vm.project.name + ".lmproj.json") },
            onImportFile = { importFile.launch(arrayOf("application/json", "*/*")) })
        Dlg.EFFECTS -> InfoDialog("Effects", """
            Status: NOT IMPLEMENTED YET (Stage 3).

            No effect is shown as working until it really processes frames in preview and export. The NODE VIDEO EFFECTS category will appear here once the GPU shader pipeline exists.""".trimIndent()) { dlg = Dlg.NONE }
        Dlg.REMAP -> InfoDialog("TIME REMAPPING", """
            Status: NOT IMPLEMENTED YET (Stage 5).

            The speed graph (0.1x to 10x), ramps, reverse and freeze frame will drive both preview and export. Nothing here is faked.""".trimIndent()) { dlg = Dlg.NONE }
        Dlg.EXPORT -> InfoDialog("Export", """
            Status: NOT IMPLEMENTED YET (Stage 6).

            Resolution, fps, bitrate and codec selection will arrive with the GL-to-MediaCodec export pipeline.
            Use Projects > Export file to back up your project in the meantime.""".trimIndent()) { dlg = Dlg.NONE }
    }
}

@Composable
fun SyncPlayer(player: ExoPlayer, layer: Layer?, playheadMs: Long, playing: Boolean) {
    val uri = layer?.uri
    val srcPos = if (layer != null) (playheadMs - layer.startMs + layer.inMs).coerceAtLeast(0L) else 0L
    val latestSrcPos by rememberUpdatedState(srcPos)

    LaunchedEffect(layer?.id) {
        if (uri != null) { player.setMediaItem(MediaItem.fromUri(Uri.parse(uri))); player.prepare() }
        else player.clearMediaItems()
    }
    LaunchedEffect(layer?.id, playing) {
        if (layer != null) player.seekTo(latestSrcPos)
        player.playWhenReady = playing && layer != null
        while (playing && layer != null) {      // keep audio/video locked to the timeline clock
            delay(400)
            if (abs(player.currentPosition - latestSrcPos) > 250) player.seekTo(latestSrcPos)
        }
    }
    LaunchedEffect(playheadMs) { if (!playing && layer != null) player.seekTo(srcPos) }
}

@Composable
fun TopBar(vm: EditorViewModel, onProjects: () -> Unit, onSettings: () -> Unit, onExport: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onProjects) { Text("☰ Projects", color = Color.White, fontSize = 13.sp) }
        Text(vm.project.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1,
            modifier = Modifier.weight(1f).clickable { onSettings() }, fontSize = 15.sp)
        TextButton(onClick = onSettings) { Text("⚙", color = Color.White, fontSize = 18.sp) }
        Button(onClick = onExport, shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
            Text("Export", fontSize = 13.sp)
        }
    }
}

@Composable
fun PreviewPane(vm: EditorViewModel, player: ExoPlayer, hasVideo: Boolean, modifier: Modifier) {
    val p = vm.project
    Box(modifier.padding(6.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.aspectRatio(p.width.toFloat() / p.height).background(Color.Black)) {
            if (hasVideo) {
                AndroidView(factory = { c -> PlayerView(c).apply { useController = false; this.player = player } },
                    modifier = Modifier.fillMaxSize())
            }
            vm.activeLayers(LayerType.IMAGE).forEach {
                AsyncImage(model = it.uri, contentDescription = null, modifier = Modifier.fillMaxSize())
            }
            vm.activeLayers(LayerType.TEXT).forEach {
                Text(it.text ?: "", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center).padding(12.dp))
            }
            if (p.layers.isEmpty()) {
                Text("Add media to start", color = Color.Gray, modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun Transport(vm: EditorViewModel) {
    Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = vm::undo, enabled = vm.canUndo) { Text("↶", fontSize = 20.sp) }
        TextButton(onClick = vm::redo, enabled = vm.canRedo) { Text("↷", fontSize = 20.sp) }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = { vm.isPlaying = false; vm.seek(0) }) { Text("⏮", fontSize = 18.sp) }
        TextButton(onClick = { vm.stepFrame(-1) }) { Text("◀|", fontSize = 15.sp) }
        FilledIconButton(onClick = vm::togglePlay) { Text(if (vm.isPlaying) "⏸" else "▶", fontSize = 18.sp) }
        TextButton(onClick = { vm.stepFrame(1) }) { Text("|▶", fontSize = 15.sp) }
        TextButton(onClick = { vm.isPlaying = false; vm.seek(vm.totalMs) }) { Text("⏭", fontSize = 18.sp) }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = { vm.zoom(0.8f) }) { Text("−", fontSize = 20.sp) }
        TextButton(onClick = { vm.zoom(1.25f) }) { Text("+", fontSize = 20.sp) }
    }
    Text(fmtTime(vm.playheadMs, vm.project.fps) + "  /  " + fmtTime(vm.totalMs, vm.project.fps),
        color = Blue, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().background(Panel).padding(start = 12.dp, bottom = 4.dp))
}

@Composable
fun TimelinePanel(vm: EditorViewModel, modifier: Modifier) {
    val density = LocalDensity.current.density
    val pps = vm.pxPerSec
    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    val contentW = (vm.totalMs / 1000f * pps).dp + 160.dp
    val seconds = (vm.totalMs / 1000).toInt() + 3
    val labelStep = if (pps < 30) 10 else if (pps < 60) 5 else 1
    fun msAt(xPx: Float) = (xPx / density / pps * 1000).toLong()

    Box(modifier.background(Bg)) {
        Box(Modifier.fillMaxSize().horizontalScroll(hScroll)) {
            Box(Modifier.width(contentW).fillMaxHeight()) {
                Column(Modifier.fillMaxSize().verticalScroll(vScroll).padding(top = 30.dp)) {
                    vm.project.layers.forEach { l ->
                        val color = when (l.type) {
                            LayerType.VIDEO -> Purple
                            LayerType.IMAGE -> Color(0xFF6366F1)
                            LayerType.AUDIO -> Color(0xFF0EA5A4)
                            LayerType.TEXT -> Blue
                        }
                        val sel = l.id == vm.selectedId
                        Box(Modifier.fillMaxWidth().height(38.dp).padding(vertical = 2.dp)) {
                            Box(Modifier
                                .offset(x = (l.startMs / 1000f * pps).dp)
                                .width((l.durationMs / 1000f * pps).dp)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(6.dp))
                                .background(color)
                                .border(if (sel) 2.dp else 0.dp, Color.White, RoundedCornerShape(6.dp))
                                .clickable { vm.select(l.id) }
                                .pointerInput(l.id, pps) {
                                    detectDragGestures(
                                        onDragStart = { vm.select(l.id); vm.beginEdit() },
                                        onDragEnd = { vm.endEdit() },
                                    ) { change, drag ->
                                        change.consume()
                                        vm.moveLive(l.id, msAt(drag.x))
                                    }
                                }
                            ) {
                                Text(l.name, color = Color.White, fontSize = 11.sp, maxLines = 1,
                                    modifier = Modifier.align(Alignment.CenterStart).padding(horizontal = 6.dp))
                            }
                        }
                    }
                }
                // ruler (tap or drag to scrub)
                Box(Modifier.fillMaxWidth().height(30.dp).background(Panel)
                    .pointerInput(pps) { detectTapGestures { vm.isPlaying = false; vm.seek(msAt(it.x)) } }
                    .pointerInput(pps) { detectDragGestures { c, _ -> c.consume(); vm.seek(msAt(c.position.x)) } }
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        for (s in 0..seconds) {
                            val x = s * pps * density
                            drawLine(Color.Gray, androidx.compose.ui.geometry.Offset(x, size.height - 8.dp.toPx()),
                                androidx.compose.ui.geometry.Offset(x, size.height), 1f)
                        }
                    }
                    for (s in 0..seconds step labelStep) {
                        Text("%d:%02d".format(s / 60, s % 60), color = Color.LightGray, fontSize = 10.sp,
                            modifier = Modifier.offset(x = (s * pps).dp + 3.dp, y = 2.dp))
                    }
                }
                // playhead
                Box(Modifier.offset(x = (vm.playheadMs / 1000f * pps).dp).width(2.dp).fillMaxHeight()
                    .background(Brush.verticalGradient(listOf(Purple, Blue))))
            }
        }
    }
}

@Composable
fun ToolTray(vm: EditorViewModel, onMedia: () -> Unit, onAudio: () -> Unit, onText: () -> Unit, onEffects: () -> Unit, onRemap: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel).horizontalScroll(rememberScrollState()).padding(vertical = 6.dp, horizontal = 4.dp)) {
        ToolBtn("🎬", "Media", onMedia)
        ToolBtn("🎵", "Audio", onAudio)
        ToolBtn("T", "Text", onText)
        ToolBtn("✨", "Effects", onEffects)
        ToolBtn("⏱", "TIME REMAPPING", onRemap, accent = true)
        ToolBtn("✂", "Split", vm::splitSelected)
        ToolBtn("🗑", "Delete", vm::deleteSelected)
    }
}

@Composable
fun ToolBtn(icon: String, label: String, onClick: () -> Unit, accent: Boolean = false) {
    Column(
        Modifier.padding(horizontal = 4.dp).clip(RoundedCornerShape(10.dp))
            .background(if (accent) Purple else Panel2).clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 18.sp)
        Text(label, fontSize = 10.sp, color = Color.White, fontWeight = if (accent) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun TextDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add text") },
        text = { OutlinedTextField(t, { t = it }, label = { Text("Text") }) },
        confirmButton = { TextButton(onClick = { onAdd(t) }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun SettingsDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(vm.project.name) }
    val sizes = listOf("720p" to (1280 to 720), "1080p" to (1920 to 1080), "9:16" to (1080 to 1920), "1:1" to (1080 to 1080))
    var size by remember { mutableStateOf(vm.project.width to vm.project.height) }
    var fps by remember { mutableIntStateOf(vm.project.fps) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Project settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                Text("Canvas", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    sizes.forEach { (l, s) -> FilterChip(size == s, { size = s }, label = { Text(l) }) }
                }
                Text("Frame rate", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(24, 30, 60).forEach { f -> FilterChip(fps == f, { fps = f }, label = { Text("$f") }) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.rename(name); vm.setFormat(size.first, size.second, fps); onDismiss() }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun ProjectsDialog(vm: EditorViewModel, onDismiss: () -> Unit, onExportFile: () -> Unit, onImportFile: () -> Unit) {
    var list by remember { mutableStateOf(vm.listProjects()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Projects") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 240.dp)) {
                    items(list, key = { it.id }) { p ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(p.name + if (p.id == vm.project.id) "  (open)" else "", modifier = Modifier.weight(1f)
                                .clickable { vm.openProject(p.id); onDismiss() }.padding(vertical = 10.dp))
                            if (p.id != vm.project.id) TextButton(onClick = { vm.deleteProject(p.id); list = vm.listProjects() }) { Text("Delete") }
                        }
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    TextButton(onClick = { vm.newProject(); onDismiss() }) { Text("New") }
                    TextButton(onClick = { vm.duplicateProject(); onDismiss() }) { Text("Duplicate") }
                    TextButton(onClick = { onImportFile(); onDismiss() }) { Text("Import") }
                    TextButton(onClick = { onExportFile(); onDismiss() }) { Text("Export file") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

@Composable
fun InfoDialog(title: String, body: String, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(body, fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } })
}
