package com.loosemotion.app

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID
import kotlin.math.max

class EditorViewModel(private val app: Application) : AndroidViewModel(app) {
    private val store = ProjectStore(app)

    var project by mutableStateOf(store.loadLast() ?: Project())
        private set
    var selectedId by mutableStateOf<String?>(null)
        private set
    var playheadMs by mutableLongStateOf(0L)
    var isPlaying by mutableStateOf(false)
    var pxPerSec by mutableFloatStateOf(80f)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()

    val totalMs: Long get() = max(1000L, project.layers.maxOfOrNull { it.startMs + it.durationMs } ?: 0L)
    val selected: Layer? get() = project.layers.firstOrNull { it.id == selectedId }

    fun activeLayers(type: LayerType): List<Layer> = project.layers.filter {
        it.type == type && playheadMs >= it.startMs && playheadMs < it.startMs + it.durationMs
    }

    private fun flags() { canUndo = undoStack.isNotEmpty(); canRedo = redoStack.isNotEmpty() }

    private fun persist() {
        val p = project.copy(modified = System.currentTimeMillis())
        viewModelScope.launch(Dispatchers.IO) { runCatching { store.save(p) } }
    }

    private fun commit(newProject: Project) {
        undoStack.addLast(project)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        project = newProject
        flags(); persist()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(project); project = undoStack.removeLast(); flags(); persist()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(project); project = redoStack.removeLast(); flags(); persist()
    }

    // ---- transport ----
    fun togglePlay() { if (playheadMs >= totalMs) playheadMs = 0; isPlaying = !isPlaying }
    fun seek(ms: Long) { playheadMs = ms.coerceIn(0, totalMs) }
    fun stepFrame(dir: Int) { isPlaying = false; seek(playheadMs + dir * (1000L / project.fps)) }
    fun zoom(factor: Float) { pxPerSec = (pxPerSec * factor).coerceIn(15f, 400f) }
    fun select(id: String?) { selectedId = id }

    // ---- layers ----
    fun addText(text: String) {
        if (text.isBlank()) return
        val l = Layer(type = LayerType.TEXT, name = text.take(20), text = text, startMs = playheadMs, durationMs = 3000)
        commit(project.copy(layers = project.layers + l)); selectedId = l.id
    }

    fun addMedia(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            var cursor = playheadMs
            val added = withContext(Dispatchers.IO) {
                uris.mapNotNull { uri ->
                    runCatching {
                        app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    val mime = app.contentResolver.getType(uri) ?: ""
                    val type = when {
                        mime.startsWith("video") -> LayerType.VIDEO
                        mime.startsWith("audio") -> LayerType.AUDIO
                        mime.startsWith("image") -> LayerType.IMAGE
                        else -> return@mapNotNull null
                    }
                    var dur = 5000L
                    if (type != LayerType.IMAGE) {
                        val r = MediaMetadataRetriever()
                        runCatching {
                            r.setDataSource(app, uri)
                            dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5000L
                        }
                        runCatching { r.release() }
                    }
                    val name = uri.lastPathSegment?.substringAfterLast('/')?.take(24) ?: type.name
                    Layer(type = type, name = name, uri = uri.toString(), startMs = cursor, durationMs = dur)
                        .also { cursor += dur }
                }
            }
            if (added.isNotEmpty()) { commit(project.copy(layers = project.layers + added)); selectedId = added.last().id }
        }
    }

    fun deleteSelected() {
        val s = selected ?: return
        commit(project.copy(layers = project.layers.filter { it.id != s.id })); selectedId = null
    }

    fun splitSelected() {
        val s = selected ?: return
        val cut = playheadMs - s.startMs
        if (cut < 100 || cut > s.durationMs - 100) return
        val a = s.copy(durationMs = cut)
        val b = s.copy(id = UUID.randomUUID().toString(), startMs = playheadMs,
            durationMs = s.durationMs - cut, inMs = s.inMs + cut)
        commit(project.copy(layers = project.layers.flatMap { if (it.id == s.id) listOf(a, b) else listOf(it) }))
        selectedId = b.id
    }

    // dragging a clip: one undo step per drag
    fun beginEdit() { undoStack.addLast(project); redoStack.clear(); flags() }
    fun moveLive(id: String, deltaMs: Long) {
        project = project.copy(layers = project.layers.map {
            if (it.id == id) it.copy(startMs = max(0L, it.startMs + deltaMs)) else it
        })
    }
    fun endEdit() = persist()

    // ---- projects ----
    fun rename(name: String) { if (name.isNotBlank()) commit(project.copy(name = name.trim())) }
    fun setFormat(w: Int, h: Int, fps: Int) = commit(project.copy(width = w, height = h, fps = fps))
    fun listProjects(): List<Project> = store.list()

    private fun switchTo(p: Project) {
        isPlaying = false; playheadMs = 0; selectedId = null
        undoStack.clear(); redoStack.clear(); project = p; flags(); persist()
    }
    fun newProject() = switchTo(Project())
    fun openProject(id: String) { store.load(id)?.let { switchTo(it) } }
    fun duplicateProject() = switchTo(project.copy(id = UUID.randomUUID().toString(), name = project.name + " copy"))
    fun deleteProject(id: String) { if (id != project.id) store.delete(id) }

    fun exportProjectFile(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        runCatching { app.contentResolver.openOutputStream(uri)?.use { it.write(project.toJson().toString().toByteArray()) } }
    }

    fun importProjectFile(uri: Uri) = viewModelScope.launch {
        val p = withContext(Dispatchers.IO) {
            runCatching {
                val text = app.contentResolver.openInputStream(uri)!!.use { it.readBytes().decodeToString() }
                Project.fromJson(JSONObject(text)).copy(id = UUID.randomUUID().toString())
            }.getOrNull()
        }
        if (p != null) switchTo(p)
    }
}
