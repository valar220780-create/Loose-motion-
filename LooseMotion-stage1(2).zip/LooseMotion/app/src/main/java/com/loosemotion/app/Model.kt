package com.loosemotion.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class LayerType { VIDEO, IMAGE, AUDIO, TEXT }

data class Layer(
    val id: String = UUID.randomUUID().toString(),
    val type: LayerType,
    val name: String,
    val uri: String? = null,
    val text: String? = null,
    val startMs: Long = 0L,
    val durationMs: Long = 3000L,
    val inMs: Long = 0L,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("type", type.name).put("name", name)
        .put("uri", uri ?: JSONObject.NULL).put("text", text ?: JSONObject.NULL)
        .put("startMs", startMs).put("durationMs", durationMs).put("inMs", inMs)

    companion object {
        fun fromJson(o: JSONObject) = Layer(
            id = o.getString("id"),
            type = LayerType.valueOf(o.getString("type")),
            name = o.getString("name"),
            uri = if (o.isNull("uri")) null else o.getString("uri"),
            text = if (o.isNull("text")) null else o.getString("text"),
            startMs = o.getLong("startMs"),
            durationMs = o.getLong("durationMs"),
            inMs = o.optLong("inMs", 0L),
        )
    }
}

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled",
    val width: Int = 1920,
    val height: Int = 1080,
    val fps: Int = 30,
    val layers: List<Layer> = emptyList(),
    val modified: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("width", width).put("height", height)
        .put("fps", fps).put("modified", modified)
        .put("layers", JSONArray().also { a -> layers.forEach { a.put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject): Project {
            val arr = o.getJSONArray("layers")
            return Project(
                id = o.getString("id"), name = o.getString("name"),
                width = o.getInt("width"), height = o.getInt("height"), fps = o.getInt("fps"),
                layers = List(arr.length()) { Layer.fromJson(arr.getJSONObject(it)) },
                modified = o.optLong("modified", 0L),
            )
        }
    }
}

class ProjectStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "projects").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("loosemotion", Context.MODE_PRIVATE)

    fun save(p: Project) {
        val tmp = File(dir, "${p.id}.tmp")
        tmp.writeText(p.toJson().toString())
        tmp.renameTo(File(dir, "${p.id}.json"))
        prefs.edit().putString("last", p.id).apply()
    }

    fun load(id: String): Project? = runCatching {
        Project.fromJson(JSONObject(File(dir, "$id.json").readText()))
    }.getOrNull()

    /** Reopens the last project, which is what recovers unfinished work after a crash. */
    fun loadLast(): Project? = prefs.getString("last", null)?.let { load(it) }

    fun list(): List<Project> = (dir.listFiles { f -> f.extension == "json" } ?: emptyArray())
        .mapNotNull { f -> runCatching { Project.fromJson(JSONObject(f.readText())) }.getOrNull() }
        .sortedByDescending { it.modified }

    fun delete(id: String) { File(dir, "$id.json").delete() }
}
